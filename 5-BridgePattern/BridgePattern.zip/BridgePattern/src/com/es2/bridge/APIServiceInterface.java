package com.es2.bridge;


public interface APIServiceInterface {

    String getContent(String contentId);


    String setContent(String content);
}

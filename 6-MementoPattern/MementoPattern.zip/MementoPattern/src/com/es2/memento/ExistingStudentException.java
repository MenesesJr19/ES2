package com.es2.memento;

import java.io.Serializable;

public class ExistingStudentException extends Exception implements Serializable {
    public ExistingStudentException() {

    }
    //ez frag

}

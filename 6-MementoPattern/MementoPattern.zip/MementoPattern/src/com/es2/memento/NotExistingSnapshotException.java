package com.es2.memento;

import java.io.Serializable;

public class NotExistingSnapshotException extends Exception implements Serializable {
    public NotExistingSnapshotException() {

    }
    //ez frag

}
